let score = 0;
let objects = []
let bgColor;
let cursorSprite;

function radiansLerp(origin, target, speed) {
  let cs = (1-speed)*Math.cos(origin) + speed*Math.cos(target);
  let sn = (1-speed)*Math.sin(origin) + speed*Math.sin(target);
  return Math.atan2(sn, cs)
}

let explosion = {
  sprite: null,
  x: null,
  y: null,
  size: 0,
  angle: 0,
  maxSize: null,
  
  explode: function explode(x,y,maxSize) {
    let newExplosion = Object.assign({}, this);
    newExplosion.x = x;
    newExplosion.y = y;
    newExplosion.maxSize = maxSize;
    newExplosion.angle = Math.random(360*PI/180);
    objects.push(newExplosion);
  },
  
  refresh: function refresh() {
    translate((width/2)-this.x, (height/2)-this.y)
    this.size = lerp(this.size, this.maxSize, 0.5)
    rotate(this.angle);
    image(this.sprite, -this.size/2, -this.size/2, this.size, this.size);
    rotate(-this.angle);
    translate(-((width/2)-this.x), -((height/2)-this.y));
    if(this.size >= this.maxSize-0.1) {
      objects.splice(objects.indexOf(this), 1);
      delete this
    }
  }
}

let laser = {
  sprite: null,
  x: null,
  y: null,
  offsetX: null,
  offsetY: null,
  angle: null,
  speed: 26,
  hitbox: 10,
  damage: 1,
  lifeTime: 10000,
  exception: null,
  velocityX: null,
  velocityY: null,
  despawn: function despawn() {
    setTimeout(() => {
      if (this && objects.includes(this)) {
        objects.splice(objects.indexOf(this), 1);
        delete this
      }
    }, this.lifeTime)
  },
  refresh: function refresh() {
    this.x -= this.velocityX;
    this.y -= this.velocityY;
    translate((width/2)-this.x, (height/2)-this.y)
    rotate(this.angle+(90*(PI/180)));
    translate(this.offsetX+2, this.offsetY);
    image(this.sprite, -40, -40, 80, 80)
    translate(-this.offsetX-2, -this.offsetY)
    rotate(-(this.angle+(90*(PI/180))))
    translate(-((width/2)-this.x), -((height/2)-this.y))
    
    for (let obj = objects.length-1; 0 <= obj; obj--) {
      if (objects[obj] && "hitEvent" in objects[obj] && objects[obj].sprite != this.sprite && objects[obj].defaultSprite != this.exception && dist(this.x, this.y, objects[obj].x, objects[obj].y) <= this.hitbox+objects[obj].hitbox) {
        objects[obj].hitEvent(this.damage);
        objects.splice(objects.indexOf(this), 1);
        delete this
      }
    }
  },
  hitEvent: function(damage) {
    objects.splice(objects.indexOf(this), 1);
    delete this
  }
}

let ship = {
  sprite: null,
  defaultSprite: null,
  shootingSprite: null,
  health: 3000000,
  
  x: 0,
  y: 0,
  hitbox: 25,
  
  speed: 0,
  topSpeed: 20,
  velocityX: 0,
  velocityY: 0,
  acceleration: 0.2,
  
  angle: 0,
  targetAngle: 0,
  
  turnSpeed: 0.1,
  brakeSpeed: 0.05,
  
  firerate: 250,
  fireCD: false,
  
  drift: function drift() {
    this.speed = Math.max(0, this.speed-this.brakeSpeed);
    this.velocityX = lerp(this.velocityX, cos(this.angle) * this.speed, 0.02)
    this.velocityY = lerp(this.velocityY, sin(this.angle) * this.speed, 0.02)
  },
  
  shoot: function shoot(offX, offY) {
    if (!this.fireCD) {
      for (let i = 0; i<2; i++) {
        this.fireCD = true;
        this.sprite = this.shootingSprite;
        let projectile = Object.assign({}, laser);
        projectile.exception = this.defaultSprite
        projectile.x = this.x;
        projectile.y = this.y;
        projectile.offsetX = offX;
        projectile.offsetY = offY;
        offX *= -1;
        offY *= -1;
        projectile.angle = this.angle;
        projectile.velocityX = Math.cos(projectile.angle) * projectile.speed;
        projectile.velocityY = Math.sin(projectile.angle) * projectile.speed;
        projectile.despawn();
        objects.push(projectile);
      }
      setTimeout(() => {
        this.sprite = this.defaultSprite;
      }, 100)
      setTimeout(() => {
        this.fireCD = false
      }, this.firerate)
    }
  },
  
  hitEvent: function hitEvent(damage) {
    this.health -= damage
    bgColor = "red"
    setTimeout(() => {
      bgColor = (99,0,99);
    }, 100)
    if (this.health <= 0) {
      explosion.explode(this.x, this.y, 100)
      objects.splice(objects.indexOf(this), 1)
      delete this;
    }
  },
  
  refresh: function refresh() {
    //ship rotation
    this.targetAngle = Math.atan2(mouseY - height/2, mouseX - width/2);
    this.angle = radiansLerp(this.angle, this.targetAngle, this.turnSpeed);
    //drift
    if (keyIsDown(SHIFT)) {
      this.drift()
    } else { //drive
      this.speed = Math.min(this.topSpeed, this.speed+this.acceleration)
      this.velocityX = lerp(this.velocityX, Math.cos(this.angle) * this.speed, 0.1)
      this.velocityY = lerp(this.velocityY, Math.sin(this.angle) * this.speed, 0.1)
    }
    //move
    this.x -= this.velocityX
    this.y -= this.velocityY
    //draw ship
    translate((width/2)-this.x, (height/2)-this.y)
    rotate(this.angle+(90*(PI/180)));
    image(this.sprite, -37.5, -37.5, 75, 75);
    rotate(-(this.angle+(90*(PI/180))))
    translate(-((width/2)-this.x), -((height/2)-this.y))
  }
}

let maxEnemies = 3;
let enemyAmount = 0;
let enemyShip = {
  sprite: null,
  defaultSprite: null,
  shootingSprite: null,
  laserSprite: null,
  health: 10,
  enemy: true,
  
  x: 0,
  y: 0,
  hitbox: 25,
  
  speed: 0,
  topSpeed: 25,
  velocityX: 0,
  velocityY: 0,
  acceleration: 1,
  
  angle: 0,
  targetAngle: 0,
  
  turnSpeed: 0.5,
  brakeSpeed: 1.5,
  
  firerate: 300,
  fireCD: false,
  
  shoot: function shoot(offX, offY) {
    if (!this.fireCD) {
      for (let i = 0; i<2; i++) {
        this.fireCD = true
        this.sprite = this.shootingSprite;
        let projectile = Object.assign({}, laser);
        projectile.sprite = this.laserSprite;
        projectile.exception = this.defaultSprite;
        projectile.x = this.x;
        projectile.y = this.y;
        projectile.offsetX = offX;
        projectile.offsetY = offY;
        offX *= -1
        offY *= -1
        projectile.angle = this.angle+PI;
        projectile.velocityX = Math.cos(projectile.angle) * projectile.speed
        projectile.velocityY = Math.sin(projectile.angle) * projectile.speed
        projectile.despawn()
        objects.push(projectile);
      }
      setTimeout(() => {
        this.sprite = this.defaultSprite;
      }, 100)
      setTimeout(() => {
        this.fireCD = false
      }, this.firerate)
    }
  },
  
  drift: function drift() {
    this.turnSpeed = 0.3
    this.speed = Math.max(0, this.speed-this.brakeSpeed);
    this.velocityX = lerp(this.velocityX, cos(this.angle) * this.speed, 0.02)
    this.velocityY = lerp(this.velocityY, sin(this.angle) * this.speed, 0.02)
  },
  
  hitEvent: function hitEvent(damage) {
    this.health -= 5;
    if (this.health == 0) {
      explosion.explode(this.x, this.y, 100)
      score++
      if (ship.health < 30) {
        ship.health += 5
      }
      enemyAmount--
      objects.splice(objects.indexOf(this), 1)
      delete this
    }
  },
  
  refresh: function refresh() {
    //line((width/2)-this.x, (height/2)-this.y, (width/2)-ship.x, (height/2)-ship.y)
    this.targetAngle = Math.atan2(ship.y-this.y, ship.x-this.x);
    for (let obj = 0; obj<objects.length; obj++) {
      if (objects[obj] != this && "enemy" in objects[obj] && dist(this.x, this.y, objects[obj].x, objects[obj].y) < 100) {
        this.targetAngle = -Math.atan2(objects[obj].y - this.y, objects[obj].x - this.x);
      }
    }
    this.angle = radiansLerp(this.angle, this.targetAngle, this.turnSpeed);
    this.turnSpeed = 0.5
     if (dist(this.x, this.y, ship.x, ship.y) < 600) {
      this.shoot(11.5,0)
    }
    if (dist(this.x, this.y, ship.x, ship.y) < 300) {
      this.drift()
    } else {
      this.speed = Math.min(this.topSpeed, this.speed+this.acceleration)
      this.velocityX = lerp(this.velocityX, Math.cos(this.angle) * this.speed, 0.05)
      this.velocityY = lerp(this.velocityY, Math.sin(this.angle) * this.speed, 0.05)
    }
    
    this.x += this.velocityX
    this.y += this.velocityY
    
    translate((width/2)-this.x, (height/2)-this.y)
    rotate(this.angle+(-90*(PI/180)));
    image(this.sprite, -37.5, -37.5, 75, 75);
    rotate(-(this.angle+(-90*(PI/180))))
    translate(-((width/2)-this.x), -((height/2)-this.y))
  }
}

function setup() {
  createCanvas(windowWidth-25, windowHeight-25, P2D);
  ship.x = width/2
  ship.y = width/2
  //load images
  ship.defaultSprite = loadImage("/Images/Spaceship.png");
  ship.shootingSprite = loadImage("/Images/SpaceshipShooting.png");
  enemyShip.defaultSprite = loadImage("/Images/Enemyship.png")
  enemyShip.shootingSprite = loadImage("/Images/EnemyshipShooting.png")
  enemyShip.sprite = enemyShip.defaultSprite
  enemyShip.laserSprite = (loadImage("/Images/EnemyLaser.png"))
  laser.sprite = loadImage("/Images/FriendlyLaser.png");
  ship.sprite = ship.defaultSprite;
  objects.push(ship);
  bgColor = (99,0,99)
  explosion.sprite = loadImage("/Images/Explosion.png")
  textFont("Verdana")
  cursorSprite = loadImage("/Images/Cursor.png")
  noCursor()
  textSize(64);
}

function randint(min, max) {
  return min + Math.floor(Math.random() * (max-min));
}

function bg() {
  let backgroundPrecision = 15;
  for (let x = 0; x < width; x += backgroundPrecision) {
    for (let y = 0; y < height; y += backgroundPrecision) {
      let noiseValue = 99 * noise(0.01 * (x-ship.x), 0.01 * (y-ship.y));
      let fillColor = color(noiseValue, 0, noiseValue);
      fillColor.setAlpha(200)
      fill(fillColor)
      rect(x, y, backgroundPrecision*1.1, backgroundPrecision*1.1);
    }
  }
}

function draw() {
  background(bgColor);
  fill("lime")
  rect(width/2-235,600,470/(30/ship.health),50);
  noStroke()
  bg();
  stroke("maroon");
  strokeWeight(3)
  fill("green");
  text(score, width-100, 80);
  image(cursorSprite, mouseX-50, mouseY-50, 100, 100);
  translate(ship.x, ship.y);
  //shoot
  if (keyIsDown(69)) {
    ship.shoot(11.5, 0);
  }
  //Rolling for enemy spawn
  if (enemyAmount != maxEnemies + int(score/5)) {
    let newEnemy = Object.assign({}, enemyShip);
    newEnemy.x = ship.x + randint(width, width+1000)*Math.floor(Math.random() < 0.5 ? -1 : 1);
    newEnemy.y = ship.y + randint(height, height+1000)*Math.floor(Math.random() < 0.5 ? -1 : 1);
    objects.push(newEnemy);
    enemyAmount++
  }
  //objects
  for (let obj = 0; obj < objects.length; obj++) {
    objects[obj].refresh()
  }
}