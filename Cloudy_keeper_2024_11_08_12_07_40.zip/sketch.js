function randint(min, max) {
    return Math.floor(Math.random() * (max-min) + min);
  }

const world = {
  x: 1350,
  y: 650,
  dye: 40
}

let snake = {
  shrinkSpeed: 5000,
  len: 2,
  segmentsX: [300, 300],
  segmentsY: [300, 300],
  segmentWidth: 10,
  dye: "rgb(0,0,255)",
  shrink: function shrink() {
    setTimeout(() => {
      this.len-=1
      this.segmentsX.shift()
      this.segmentsY.shift()
      this.shrinkSpeed-= 100
      this.shrink()
      console.log(this.shrinkSpeed)
    }, this.shrinkSpeed)
  }
}

let apple = {
  size: 20,
  x: 0,
  y: 0,
  dye: "rgb(0,255,0)",
  spawn: function spawn() {
    this.x = randint(this.size*2, world.x);
    this.y = randint(this.size*2, world.y);
  }
}

let score = 0

function setup() {
  createCanvas(world.x, world.y);
  apple.spawn()
  snake.shrink()
}

function draw() {
  background(world.dye)
  textSize(30)
  fill("red")
  text(score, 20, 50)
  if (Math.abs(snake.segmentsX[snake.segmentsX.length-1]-mouseX) > snake.len || Math.abs(snake.segmentsY[snake.segmentsY.length-1]-mouseY) > 10) {
    snake.segmentsX.push(snake.segmentsX[snake.segmentsX.length-2]-(snake.segmentsX[snake.segmentsX.length-2]-mouseX)/10)
    snake.segmentsY.push(snake.segmentsY[snake.segmentsY.length-2]-(snake.segmentsY[snake.segmentsY.length-2]-mouseY)/10)
  }
  if (snake.segmentsX.length > snake.len) {
    snake.segmentsX.shift()
    snake.segmentsY.shift()
  }
  fill(snake.dye)
  strokeWeight(snake.segmentWidth)
  stroke(snake.dye)
  for (let segment = 1; segment<snake.segmentsX.length; segment++) {
    line(snake.segmentsX[segment-1], snake.segmentsY[segment-1], snake.segmentsX[segment], snake.segmentsY[segment])
  }
  strokeWeight(0);
  fill(apple.dye)
  circle(apple.x, apple.y, apple.size)
  if (dist(snake.segmentsX[snake.segmentsX.length-1], snake.segmentsY[snake.segmentsY.length-1], apple.x, apple.y) < apple.size) {
    snake.len += 1
    score++
    apple.spawn()
  }
}